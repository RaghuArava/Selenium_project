from behave import *
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time

@given('Launch the Chrome Browser')
def openBrowser(context):
    context.driver=webdriver.Chrome()
    context.driver.maximize_window()

@when('open a coinmarketcap homepage')
def LauchHomepage(context):
    context.driver.get("https://coinmarketcap.com/")

@then('click on view all and verify the "{req_num}" rows')
def clickViewAll(context,req_num):
    context.driver.get("https://coinmarketcap.com/all/")
    tbody_tr_lst=context.driver.find_elements_by_xpath("//tbody/tr")
    assert len(tbody_tr_lst) >= int(req_num)

@then('verify the login activity')
def Login(context):
    wait = WebDriverWait(context.driver, 15)
    wait.until(EC.element_to_be_clickable((By.XPATH,"//button[normalize-space()='Log In']"))).click()
    time.sleep(5)
    context.driver.find_element_by_xpath("//input[@placeholder='Enter your email address...']").send_keys("a.raghuvardan@gmail.com")
    time.sleep(3)
    context.driver.find_element_by_xpath("//input[@placeholder='Enter your password...']").send_keys("jagun9849037990")
    time.sleep(3)
    context.driver.find_element_by_xpath("//body[1]/div[2]/div[1]/div[1]/div[1]/div[6]/button[1]").click()
    time.sleep(15)

@then('close browser')
def closeBrowser(context):
    context.driver.close()

@then('add 5 to 10 crypto curencies to watchlist,open the watchlist in different browser and verify added currency are added.')
def AddAndVerifyWathcList(context):
    name_lst=[]
    for num in range(5, 10):
        row_xpath="//tbody/tr[%s]/td"%(str(num))
        btn_xpath="//tbody/tr[%s]/td[1]/span[1]"%(str(num))
        slctd_elmnts=context.driver.find_elements_by_xpath(row_xpath)
        name_lst.append(slctd_elmnts[2].text)
        time.sleep(3)
        btn=context.driver.find_element_by_xpath(btn_xpath)
        context.driver.execute_script("arguments[0].click();", btn)
        time.sleep(5)
    time.sleep(15)
    print(name_lst)
    context.driver.get("https://coinmarketcap.com/")
    wishlst_btn=context.driver.find_element_by_xpath("//body/div/div/div/div/div/div/div/div/div/div/a[2]")
    context.driver.execute_script("arguments[0].click();", wishlst_btn)
    tbody_tr_lst = context.driver.find_elements_by_xpath("//tbody/tr")
    time.sleep(15)
    for elmnt in tbody_tr_lst:
        print(elmnt)
        assert elmnt in tbody_tr_lst

@then('click on ranking under cryptocurrency dropdown')
def workOncryptocurrencyDrpdDwn(context):
    action = ActionChains(context.driver)
    Sourc_elmnt = context.driver.find_element_by_xpath("//span[normalize-space()='Cryptocurrencies']")
    action.move_to_element(Sourc_elmnt).perform()
    time.sleep(3)
    dest_elmnt = context.driver.find_element_by_xpath("//div[@class='i9bxs7-0 cIyizc']//div[1]//div[1]//a[1]")
    dest_elmnt.click()

@then('verify the recorded data and close the browser')
def verifyTheRankingbutunData(context):
    pass




