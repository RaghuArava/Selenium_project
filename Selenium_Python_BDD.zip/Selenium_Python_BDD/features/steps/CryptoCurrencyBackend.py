from selenium import webdriver
import requests
import json


print("============================================= SCENARIO 1 =============================================")
@given('retrive the IDs of bitcoin, (BTC) usd tether (USDT), and Ethereum (ETH)')
def prepareURLinfo(context):
    context.map_url = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/map"
    context.covert_url = "https://pro-api.coinmarketcap.com/v1/tools/price-conversion"
    context.Api_kay = "cb2db9e6-13d7-4cf3-8d45-b5337e1a91ba"
    context.headers = {'X-CMC_PRO_API_KEY': context.Api_kay, 'Accepts': 'application/json'}
    context.params = {'start': 1, 'limit': 5000}
    json_ids = requests.get(context.map_url, headers=context.headers, params=context.params)
    context.json_ids = json.loads(json_ids.content.decode('utf-8'))


@when('get the currency IDs of given coins')
def getTheCoinIds(context):
    context.Name_Id_Dict={}
    for Cr in context.json_ids:
        if Cr == "data" and isinstance(context.json_ids["data"], list):
            for data_dict in context.json_ids["data"]:
                Cr_name = data_dict["name"]
                Cr_Id = data_dict["id"]
                Cr_Symbol = data_dict["symbol"]
                if 'Bitcoin'.lower() == Cr_name.lower() or 'Ethereum'.lower() == Cr_name.lower() or 'Tether'.lower() == Cr_name.lower():
                    context.Name_Id_Dict[Cr_Id] = [Cr_name, Cr_Symbol]
    for coin_id in context.Name_Id_Dict:
        print("Name : %s id and symbol is %s & %s"%(context.Name_Id_Dict[coin_id][0], coin_id, context.Name_Id_Dict[coin_id][1]))




@then('Convert the currency to given price')
def ConvertThePrice(context):
    context.Boliviano_Dict={}
    for Cr_Id in context.Name_Id_Dict:
        Cr_name = context.Name_Id_Dict[Cr_Id][0]
        Cr_Symbol = context.Name_Id_Dict[Cr_Id][1]
        context.params_convr = {"id": Cr_Id, "amount": 1, "convert": "BOB"}
        json_covrs = requests.get(context.covert_url, headers=context.headers, params=context.params_convr)
        json_covrs = json.loads(json_covrs.content.decode('utf-8'))
        BOB_price = json_covrs['data']['quote']['BOB']['price']
        context.Boliviano_Dict[Cr_name] = BOB_price
        print("%s Boliviano price is %s"%(Cr_name,BOB_price))




print("============================================= SCENARIO 2 =============================================")
@given('prepare the test bench')
def prepareTestBench(context):
    context.Api_kay = "cb2db9e6-13d7-4cf3-8d45-b5337e1a91ba"
    context.headers = {'X-CMC_PRO_API_KEY': context.Api_kay, 'Accepts': 'application/json'}
    context.info_url = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/info"
    context.params = {"id": "1027"}
    context.id="1027"




@when('retrieve the data from cryptocurrency/info')
def retrieveThedata(context):
    json_info = requests.get(context.info_url, headers=context.headers, params=context.params)
    context.json_info = json.loads(json_info.content.decode('utf-8'))



@then('Verify the retrieved data')
def verifyThedata(context):
    for elmnt in context.json_info['data'][context.id]:
        if elmnt == "logo":
            print("%s  ===> OK" % (context.json_info['data'][context.id][elmnt]))
            assert context.json_info['data'][context.id][elmnt] == "https://s2.coinmarketcap.com/static/img/coins/64x64/1027.png"
        elif elmnt == 'urls':
            print("URL OK")
            for urls_elmnt in context.json_info['data'][context.id][elmnt]:
                if urls_elmnt == "technical_doc":
                    print(context.json_info['data'][context.id][elmnt][urls_elmnt])
                    assert "https://github.com/ethereum/wiki/wiki/White-Paper" in context.json_info['data'][context.id][elmnt][urls_elmnt]
        elif elmnt == "symbol":
            print("%s  ===> OK"%(context.json_info['data'][context.id][elmnt]))
            assert context.json_info['data'][context.id][elmnt] == "ETH"
        elif elmnt == "date_added":
            print("%s  ===> OK" % (context.json_info['data'][context.id][elmnt]))
            assert context.json_info['data'][context.id][elmnt] == "2015-08-07T00:00:00.000Z"
        elif elmnt == "platform":
            assert context.json_info['data'][context.id][elmnt] == None
            print("%s  ===> Not OK ,expected is null" % (context.json_info['data'][context.id][elmnt]))
        elif elmnt == 'tags':
            print("%s  ===> OK" % (context.json_info['data'][context.id][elmnt][0]))
            assert 'mineable' in context.json_info['data'][context.id][elmnt]



print("============================================= SCENARIO 3 =============================================")

@given('prepare the test bench to retrieve the 10 IDs info')
def prepareThaTB(context):
    context.Api_kay = "cb2db9e6-13d7-4cf3-8d45-b5337e1a91ba"
    context.headers = {'X-CMC_PRO_API_KEY': context.Api_kay, 'Accepts': 'application/json'}
    context.info_url = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/info"
    context.params = {"id": "1,2,3,4,5,6,7,8,9,10"}
    context.id="1027"

@when('retrieve teh 1,2,3,..10 IDs of info')
def retriveTheIdsInfo(context):
    json_info = requests.get(context.info_url, headers=context.headers, params=context.params)
    context.json_info = json.loads(json_info.content.decode('utf-8'))


@then('verify the data')
def verifyTheIDsInfo(context):
    Name = ''
    Slug = ''
    for Id in context.json_info['data']:
        for elmnt in context.json_info['data'][Id]:
            if elmnt == 'tags':
                assert 'mineable' in context.json_info['data'][Id][elmnt]
                print("%s : %s  ===> OK"%(elmnt, context.json_info['data'][Id][elmnt][0]))
            elif elmnt == 'name':
                Name = context.json_info['data'][Id][elmnt]
                #print("%s  ===> OK" % (context.json_info['data'][Id][elmnt]))
            elif elmnt == 'slug':
                #print("%s  ===> OK" % (context.json_info['data'][Id][elmnt]))
                Slug = context.json_info['data'][Id][elmnt]
            if Name.lower() == Slug.lower():
                print("Currency names are matched")
            else:
                print("Warning : Currency names are Not matched")
