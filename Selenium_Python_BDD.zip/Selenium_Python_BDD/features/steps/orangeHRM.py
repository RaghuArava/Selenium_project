from behave import *
from selenium import webdriver
#from webdriver_manager.chrome import ChromeDriverManager


@given('Launch chrome browser')
def launchBrowser(context):
    context.driver = webdriver.Chrome(executable_path=r"C:\Users\God\AppData\Local\Programs\Python\Python38\Scripts\chromedriver")
    #driver = webdriver.Chrome(ChromeDriverManager().install())
    context.driver.get('https://coinmarketcap.com/')
    #ele = context.driver.find_elements_by_xpath('//*[@id]')
    ele = context.driver.find_elements_by_css_selector("*")
    #for x in ele:
        #print(x.tag_name, x.get_attribute('value'))
        #print(x.tag_name, x.text)



@when('open orangeHRM homepage')
def openHomepage(context):
    #context.driver.get("https://opensource-demo.orangehrmlive.com/")
    #context.driver.get("https://coinmarketcap.com/")
    context.driver.get("https://coinmarketcap.com/all/views/all/")
    print("OK")







@then('Verify that the logo present on page')
def verifyLogo(context):
    status=context.driver.find_element_by_xpath("//div[@class='spinner-outer']").is_displayed()



@then('close the browser')
def close(context):
    context.driver.close()




